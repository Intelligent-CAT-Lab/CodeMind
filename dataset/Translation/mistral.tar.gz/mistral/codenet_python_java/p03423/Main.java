import java.util.Scanner;

public class p03423 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int num = scanner.nextInt();
        int result = num / 3;
        System.out.println(result);
    }
}