import java.util.Scanner;

public class p00310 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int p, m, c;
        p = scanner.nextInt();
        m = scanner.nextInt();
        c = scanner.nextInt();
        System.out.println(p + m + c);
    }
}