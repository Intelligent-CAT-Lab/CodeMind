import java.util.Scanner;

public class p02969 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int r = sc.nextInt();
        System.out.println(3*(r*r));
    }
}