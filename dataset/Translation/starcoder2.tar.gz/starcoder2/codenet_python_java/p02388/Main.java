import java.util.Scanner;

public class p02388 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        System.out.println(x*x*x);
    }
}