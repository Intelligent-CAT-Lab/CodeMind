import java.util.Scanner;

public class p03473 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int M = sc.nextInt();
        System.out.println(48-M);
    }
}